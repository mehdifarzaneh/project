const Yup = require("yup");

//create ticket
exports.createTicketValidate = Yup.object().shape({
  title: Yup.string().required("عنوان تیکت الزامی است"),
  content: Yup.string().required("توضیحات تیکت الزامی است").max(5200,"توضیحات تیکت نباید بیشتر از 5100 کاراکتر باشد"),
});
