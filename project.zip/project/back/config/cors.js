
const development = ['http://localhost:3000','http://localhost:3000/']
const production = ['https://developme.ir','https://developme.ir/']

const whitelist = process.env.NODE_ENV === 'development' ? development : production;

exports.corsOptionsDelegate = (req,callback) => {
    const isDomainAllowed = whitelist.some(url=> url === req.header('Origin'));
    const isRefererAllowed = whitelist.some(url=> url === req.header('referer'));
    const isExtensionAllowed = req.path.endsWith('.jpg') || req.path.endsWith('.webp') || req.path.endsWith('.jpeg') || req.path.endsWith('.png')

    if(isDomainAllowed || isExtensionAllowed || isRefererAllowed){
        callback(null, {origin:true})
    }else{
        callback(new Error("You don't have the required access"));
    }
}