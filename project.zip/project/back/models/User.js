const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    fullname:{required:true,type:String,trim:true},
    phone:{type:Number,unique:true,trim:true,required:true},
    email:{type:String,unique:true,lowercase:true},
    wallet:{type:Number,default:0},
    admin:{type:Boolean,default:false},
    image:{type:Object},
    instagram:{type:String},
    website:{type:String},
    bio:{type:String},
    updatedAt:{type:Date},
    createdAt:{type:Date,default:Date.now},
});

module.exports = mongoose.model("User", userSchema);
