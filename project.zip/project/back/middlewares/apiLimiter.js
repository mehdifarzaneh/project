const rateLimit = require('express-rate-limit');

const apiLimiter = (windowMs, max) => rateLimit({
  windowMs: 60 * 1000 * windowMs, // in miliseconds
  max,
  store: new rateLimit.MemoryStore(),
  standardHeaders: true,
  legacyHeaders: false,
});

exports.apiLimiter = (windowMs,max) => {
  const limiter = apiLimiter(windowMs,max);

  return (req, res, next) =>{
    limiter(req,res,(err) =>{
      if(err){
        // error handling
        res.status(429).send('Too many requests');
      }else{
        next();
      }
    });
  };
};
