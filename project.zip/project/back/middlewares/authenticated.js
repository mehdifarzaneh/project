const User = require('../models/User');
const jwt = require('jsonwebtoken');

exports.authenticated = async(req,res,next) => {
    try{
        const authHeader = req.get("Authorization");

        if (!authHeader) {
            return res.json({message:'ابتدا وارد حساب کاربری خود شوید' ,status:422})
        }

        const token = authHeader.split(" ")[1]; //Bearer Token => ['Bearer', token]
        const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

        if (!decodedToken){return res.json({message:'ابتدا وارد حساب کاربری خود شوید' ,status:422})}
        
        const user = await User.findOne({_id:decodedToken._id}).populate("roles")
        if(!user) return {message:"دسترسی ندارید!" ,status:404}
        if(user) req.user = user
        next();
    }catch(err){
      console.log(err)
      next(err);
    }
};

exports.checkUserPermission = (accesses, page) => async (req, res, next) => {
  try{
      const user = req.user;
      const hasAccess = user.roles.some(role => {
        if (accesses.includes(role.name) && role.pages[page].includes(req.method.toLowerCase())) return true;
        return false;
      });
    
      if(hasAccess){
        next();
      } else {
        return res.status(403).json({message:'دسترسی لازم ندارید!'})
      }
    }catch(err){
     next(err) 
    }
};
  

