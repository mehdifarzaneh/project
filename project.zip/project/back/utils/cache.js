const NodeCache = require( "node-cache" );
module.exports = new NodeCache();