const express = require("express");
const cors = require('cors');
const dotenv = require("dotenv");
const connectDB = require("./config/dataBase");
const {errorHandler}= require('./middlewares/errors');
const { corsOptionsDelegate } = require("./config/cors");

//dotenv configuration
process.env.NODE_ENV === 'development' ? dotenv.config({path: "./development.env"}) : dotenv.config({path: "./production.env"});

//database connection
connectDB();

const app = express()

app.use(cors(corsOptionsDelegate));
app.disable('x-powered-by');

//body parser
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(require("./routes/index"));

//error handler 
app.use(errorHandler)

const PORT = process.env.PORT || 11100
app.listen(PORT,()=>console.log(`App Is Running On Port ${PORT}`))