"use client"
import { useInitUser } from "@/hooks/useUser";

export default function RootLayout({children}:{children:React.ReactNode}){
  // useInitUser()

  return children
}