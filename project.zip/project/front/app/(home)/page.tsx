import Link from "next/link";

export default async function Page(){
  return (
      <main className="flex items-center text-4xl justify-center flex-col gap-y-5 font-kalamehBold">
        <h1 className="mt-20">صفحه اصلی</h1>
        <Link className="text-blue-500 underline" href="/about-us">صفحه درباره ما</Link>
      </main>
  );
}
