import Link from 'next/link';

const description = ""

export const metadata = {
  title: '',
  description,
  openGraph : {
    siteName: '',
    description,
    url: `https://...`,
    locale: 'fa_IR',
    type: 'website',
  },
  alternates: {
    canonical: `https://...`,
  },
  keywords: [],
  authors: [{ name: ''}],
  robots: {
    index: true,
    follow: true,
    googleBot:{
      index: true,
      follow: true,
    }
  }
}

export default function Page(){
  return(
    <main className="flex items-center text-4xl justify-center flex-col gap-y-5 font-kalamehBold">
      <h1 className="mt-20">صفحه دباره ما</h1>
      <Link className="text-blue-500 underline" href="/">صفحه اصلی</Link>
    </main>
  )
}