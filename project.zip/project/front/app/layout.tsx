"use client"
import QueryProviders from './Providers';
import { Providers } from '@/store/provider';

import '../styles/globals.css'
import { Toaster } from 'react-hot-toast';
import RootLayoutClient from './layout.client';

export default function RootLayout({children}:{children:React.ReactNode}){

  return(
    <Providers>
      <QueryProviders>
          <html dir='rtl' lang="fa">
            <head>
              <meta name="apple-mobile-web-app-capable" content="yes"/>
              <meta name="theme-color" content="#15B8B8" />
            </head>
            <body suppressHydrationWarning={true}>
                <RootLayoutClient/>
                {children}
                <Toaster/>
            </body>
          </html>
      </QueryProviders>
    </Providers>
  )
}