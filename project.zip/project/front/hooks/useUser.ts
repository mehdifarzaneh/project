import { refreshTokenApi } from "@/api/auth";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { clearUserAction, setUserAction } from "@/store/reducers/userSlice";
import { removeCookie } from "@/utils/Cookie";
import { useEffect, useState } from "react";

export const useInitUser = ()=>{
    const user = useAppSelector(state=>state.user)
    const [getUser,setUser] = useState<any>('')
    const dispatch = useAppDispatch()

    useEffect(()=>{
        const refreshToken = async()=>{
          try{
            const {data} = await refreshTokenApi()
            dispatch(setUserAction(data.user))
            setUser(data.user)
          }catch(err){
            console.clear()
            removeCookie("token")
            dispatch(clearUserAction())
            setUser(false)
          }
        }
        user === '' && refreshToken() 
    },[user,dispatch])

    return user ? user : getUser
}