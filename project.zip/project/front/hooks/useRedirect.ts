import { useRouter } from 'next/navigation'

export const useRedirect = (): { push: (route: string) => void, replace: (route: string) => void , back: () => void } => {
    const router = useRouter()
  
    const redirect = {
      push: (route: string) => router.push(route),
      replace: (route: string) => router.replace(route),
      back: () => router.back(),
    }
  
    return redirect
}