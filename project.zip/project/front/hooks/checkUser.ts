import { useAppSelector } from "@/store/hooks";
import { useEffect } from "react";

export const useCheckUser = ()=>{
    const user : any = useAppSelector(state=>state.user)
    // useEffect(()=>{
        // console.log(user);
       if(!user?._id) window.location.href = '/404'
    // },[user])
}