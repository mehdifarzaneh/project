import http from './httpService'

const headers = {
    'Referer': process.env.NEXT_PUBLIC_SITEURL,
    'Origin': process.env.NEXT_PUBLIC_SITEURL,
}

export const getHomePageDataApi = ()=> http.get(`/`,{headers})

