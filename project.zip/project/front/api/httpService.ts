import axios from "axios";
import Cookies from 'js-cookie'

export const app = axios.create({
  baseURL: process.env.NEXT_PUBLIC_APIURL,
});

export const headers : any = {
  'Referer': process.env.NEXT_PUBLIC_SITEURL,
  'Origin': process.env.NEXT_PUBLIC_SITEURL,
}

app.interceptors.request.use((res)=>res,(err) => Promise.reject(err));

if(typeof window !== "undefined"){
  const token = Cookies.get("token");
  if(token) app.defaults.headers.common["Authorization"] = `Bearer ${token}`;
}

// app.interceptors.response.use((response) => response,(error) => {
//     if (error.response && (error.response.status === 400 || error.response.status === 500)) {
//       // اینجا هیچ عملیاتی انجام نمی‌شود و خطا به کاربر نمایش داده نمی‌شود
//       return Promise.resolve(null);
//     } else {
//       return Promise.reject(error);
//     }
//   }
// );

const http = {get:app.get, post:app.post, put:app.put, delete:app.delete};


export default http;