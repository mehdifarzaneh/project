import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface HomeState {
  comment?: any;
  categories?: any;
}

const initialState: HomeState = {
  comment: '',
  categories: '',
};

const homeSlice = createSlice({
  name: 'home',
  initialState,
  reducers: {
    setHomeAction: (state,action: PayloadAction<Partial<HomeState>>) => {
      return {...state,...action.payload };
    },
    clearHomeAction: () => {
      return {};
    },
  },
});

export const { setHomeAction, clearHomeAction } = homeSlice.actions;

export default homeSlice.reducer;
