import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface UserState {
  // value: string | boolean;
}

const initialState: UserState = '';

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUserAction: (state, action: PayloadAction<string>) => {
      return state = action.payload;
    },
    clearUserAction: (state) => {
      return state = false;
    },
  },
});

export const { setUserAction, clearUserAction } = userSlice.actions;

export default userSlice.reducer;
