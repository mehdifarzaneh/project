import { configureStore } from "@reduxjs/toolkit";
import userSlice from "./reducers/userSlice";
import homeSlice from "./reducers/homeSlice";

export const store = configureStore({
  reducer: {
    user : userSlice,
    home : homeSlice,
  },
  devTools: process.env.NODE_ENV !== "production",
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
