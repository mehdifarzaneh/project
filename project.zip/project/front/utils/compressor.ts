import Compressor from 'compressorjs';

export const ImageCompressor = async (file: File): Promise<File> => {
  return new Promise<File>((resolve, reject) => {
    new Compressor(file, {
      quality: 0.2,
      convertTypes: ['image/webp'],
      success: (compressedFile: File) => resolve(compressedFile),
      error: (err: Error) => reject(err),
    });
  });
};