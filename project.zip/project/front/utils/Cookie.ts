import Cookies from 'js-cookie';
//expires in days

export const getCookie = (name:string) => Cookies.get(name);
export const removeCookie = (name:string) => Cookies.remove(name);

export const setCookie = (name:string,value:any,options: any = {}) => {
  const subdomain = '.developme.ir';

  const domain = process.env.NODE_ENV === 'production' ? subdomain : null
  const defaultOptions : object = {path: '/',expires:options.expires || 30 ,secure: true,domain};

  Cookies.set(name,value,defaultOptions);
};