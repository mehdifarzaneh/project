
export const convertNumbersToWordsHandler = (num: number, level = 0): string => {
    const yekan = [" یک ", " دو ", " سه ", " چهار ", " پنج ", " شش ", " هفت ", " هشت ", " نه "];
    const dahgan = [" بیست ", " سی ", " چهل ", " پنجاه ", " شصت ", " هفتاد ", " هشتاد ", " نود "];
    const sadgan = [" یکصد ", " دویست ", " سیصد ", " چهارصد ", " پانصد ", " ششصد ", " هفتصد ", " هشتصد ", " نهصد "];
    const dah = [" ده ", " یازده ", " دوازده ", " سیزده ", " چهارده ", " پانزده ", " شانزده ", " هفده ", " هیجده ", " نوزده "];

    if (num === null || num === 0 || num < 0) return "";

    let result = "";

    if (level > 0) {
        result += " و ";
        level -= 1;
    }

    if (num < 10) {
        result += yekan[num - 1] ;
    } else if (num < 20) {
        result += dah[num - 10];
    } else if (num < 100) {
        result += dahgan[Math.floor(num / 10) - 2] + convertNumbersToWordsHandler(num % 10, level + 1);
    } else if (num < 1000) {
        result += sadgan[Math.floor(num / 100) - 1] + convertNumbersToWordsHandler(num % 100, level + 1);
    } else if (num < 1000000) {
        result += convertNumbersToWordsHandler(Math.floor(num / 1000), level) + " هزار " + convertNumbersToWordsHandler(num % 1000, level + 1);
    }else if (num < 1000000000) {
        result += convertNumbersToWordsHandler(Math.floor(num / 1000000), level) + " میلیون " + convertNumbersToWordsHandler(num % 1000000, level + 1);
    } else if (num < 1000000000000) {
        result += convertNumbersToWordsHandler(Math.floor(num / 1000000000), level) + " میلیارد " + convertNumbersToWordsHandler(num % 1000000000, level + 1);
    } else if (num < 1000000000000000) {
        result += convertNumbersToWordsHandler(Math.floor(num / 1000000000000), level) + " تریلیارد " + convertNumbersToWordsHandler(num % 1000000000000, level + 1);
    }

    return result;
};

export const convertNumbersToWords = (num: number): string => convertNumbersToWordsHandler(num) + " تومان "