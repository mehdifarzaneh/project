import Swal, { SweetAlertIcon } from "sweetalert2"

// Prompt alert
interface PromptAlertOptions {
    text?: string;
    icon?: SweetAlertIcon;
    timer?: number;
    confirmText?: string;
    cancelText?: string;
    position?: 'top' | 'top-start' | 'top-end' | 'center' | 'center-start' | 'center-end' | 'bottom' | 'bottom-start' | 'bottom-end';
    toast?: boolean;
}

export const PromptAlert = ({text,icon="success",timer=15000,confirmText='',cancelText='',position="center",toast=false}:PromptAlertOptions)=>{
    if('vibrate' in navigator) navigator.vibrate(400);

    return Swal.fire({
        text,
        icon,
        timer : timer ? timer : 30000,
        showConfirmButton: confirmText ? true : false,
        showCancelButton: cancelText ? true : false,
        confirmButtonText:confirmText,
        cancelButtonText:cancelText,
        customClass:"promptAlert",
        position,
        toast,
    })
}


// Toast alert
interface ToastAlertOptions {
    text: string;
    icon?: SweetAlertIcon;
    timer?: number;
    confirmText?: string;
    cancelText?: string;
    position?: 'top' | 'top-start' | 'top-end' | 'center' | 'center-start' | 'center-end' | 'bottom' | 'bottom-start' | 'bottom-end';
    toast?: boolean;
}


export const Toast = ({text,icon="success",timer=4000,confirmText='',position="bottom",toast=true}:ToastAlertOptions)=>{
    if('vibrate' in navigator) navigator.vibrate(400);

    Swal.fire({
        text,
        icon,
        timer,
        showConfirmButton: confirmText ? true : false,
        confirmButtonText: confirmText,
        customClass:"promptAlert",
        position,
        toast
    })
}