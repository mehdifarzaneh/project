import moment from "jalali-moment";
const farsiDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export const truncate = (string:string,leng:number) => {
    if (string.length > leng && string.length > 0){
        let neww = string.substr(0,leng);
        return neww + "...";
    }
    return string;
};


export const convertNumbers2English = (string: any): any => string.replace(/[\u0660-\u0669]/g, (c:any) => String.fromCharCode(c.charCodeAt(0) - 0x0660)).replace(/[\u06f0-\u06f9]/g, (c:any) => String.fromCharCode(c.charCodeAt(0) - 0x06f0));
export const HtmlToText = (html:string)=> html.replace(/<[^>]+>/g, '');
export const convertToPersianNumbers = (n:any)=> n && n.toString().replace(/\d/g, (x:any) => farsiDigits[parseInt(x)]);
export const numberWithCommas = (x:number|string)=> x && <span className="font-iranSansNumber">{x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</span>
export const getTime = (time:string)=> moment(time).format('HH:mm')
export const covertToPersionDate = (date:any)=>{return moment(date).locale("fa").format('HH:mm YYYY/MM/D')}

export const formatMobileNumber = (number:any)=>{
    const phoneNumber = `0${number}`
    const firstFourDigits = phoneNumber.slice(0,4)
    const lastTwoDigits = phoneNumber.slice(-2)
    return <span className="font-iranSansNumber">{lastTwoDigits + "****" + firstFourDigits}</span>
}

export const formatDate = (date:string)=>{
    if(!date) return null
    const inputDate = moment(date, 'YYYY-MM-DDTHH:mm:ss.SSSZ').locale('fa');
    const now = moment().locale('fa');
    const diffMinutes = now.diff(inputDate, 'minutes');
    const diffHours = now.diff(inputDate, 'hours');
    const diffDays = now.diff(inputDate, 'days');
    
    if (diffMinutes < 1) {
        return 'همین الان';
    }else if (diffMinutes < 60) {
        return <span className="font-iranSansNumber">{`${diffMinutes} دقیقه قبل`}</span>;
    }else if (diffHours < 24) {
        return <span className="font-iranSansNumber">{`${diffHours} ساعت قبل`}</span>;
    }else if (diffDays < 7) {
        return <span className="font-iranSansNumber">{`${diffDays} روز قبل`}</span>;
    }else{
        return <span className="font-iranSansNumber">{moment(date).format('HH:mm')  + " - " + moment(date).locale("fa").format('YYYY/MM/D')}</span>
    }
}

export const CheckMoreThanDays = (date:string,days:number)=>{
    const inputDate = moment(date, 'YYYY-MM-DDTHH:mm:ss.SSSZ').locale('fa');
    const now = moment().locale('fa');
    const diffDays = now.diff(inputDate,'days');

    if(diffDays>days) return true
    else return false
}

export const getDayAndMonth = (date:any)=>{
    const jDate = moment(date, 'YYYY-MM-DD').locale('fa');
    const day = jDate.format('dddd');
    const month = jDate.format('jMMMM');
    const dayOfMonth = jDate.format('jD');
    
    return <span className="font-iranSansNumber">{day + dayOfMonth + month}</span>
}

export const calculateAudioDuration = (audioFile: File): Promise<any> => {
    return new Promise<any>((resolve, reject) => {
      const audio = new Audio();
      audio.src = URL.createObjectURL(audioFile);
  
      audio.addEventListener('loadedmetadata', () => {
        const duration = audio.duration;
        const minutes = Math.floor(duration / 60);
        const seconds = Math.floor(duration % 60);
        const formattedDuration = (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
        resolve(formattedDuration);
      });
  
      audio.addEventListener('error', (error) => {
        reject(error);
      });
    });
};
