
export async function authMiddleware(request:any) {
    let token = request.cookies.get("token")?.value

    const headers : any = {
        'Referer': process.env.NEXT_PUBLIC_SITEURL,
        'Origin': process.env.NEXT_PUBLIC_SITEURL,
        'Authorization': `Bearer ${token}`,
    }

    const data : any = await fetch(`${process.env.NEXT_PUBLIC_APIURL}/auth/refreshToken`,{
        method : "GET",
        headers
    }).then(res=>res.json())

    return data.user
}