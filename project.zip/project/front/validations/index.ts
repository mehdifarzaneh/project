import * as Yup from 'yup';

export const indexServiceValidate = Yup.object().shape({
    link:Yup.string().required("لینک پست یا پیج را وارد کنید"),
});

